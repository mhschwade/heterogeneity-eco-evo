# Copyright (c) 2020, ETH Zurich

# .onLoad <- function(...) {
#   packageStartupMessage("Gen3sis: General Engine for Eco-Evolutionary Simulations. \n  Copyright (c) 2020, ETH Zurich  \n This program comes with ABSOLUTELY NO WARRANTY; This is free software, and you are welcome to redistribute it under certain conditions. \n")
# }
