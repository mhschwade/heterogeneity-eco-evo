# dev

# gen3sis (subtly modified) release 08.2024
  - change the order of the functions loop_evolution and loop_ecology()
  - first ecology and then evolution

# v.1.5.11 release 11.2023
  - fix comb phylogeny
  - color deficient, blind and B&W safe colours
  - speed-up of loop_ecology function
  - fix nexus phylo file format
  - fix accounting of extinctions times 
  - fix phylo checks if simulation did not end at t=0
  - fix package build notes citation and class comparisons

# v.1.4 release 10.2021
  - fix bracket compatibility with new R version
  - added new abundance plotting function 

# v.1.3 release 07.2021

# v.1.2 release	12.2020 

# v.1.1 release	08.2020
  
# v.1.0 release 06.2020
